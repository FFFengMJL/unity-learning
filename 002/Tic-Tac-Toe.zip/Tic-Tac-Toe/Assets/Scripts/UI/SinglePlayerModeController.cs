﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TicTacToe.UI
{
  public class SinglePlayerModeController : GameController
  {
    void Awake()
    {
      // 初始化机器人
      mechanics = new Mechanics.BotAction();
    }

    public override void AfterRenderButton(int i, int j, Mechanics.Player player, bool isPressed)
    {
      // 如果游戏并没有进行中
      if (!mechanics.GetPlaying())
      {
        return;
      }

      // 玩家的回合
      if (mechanics.GetTurn())
      {
        if (isPressed)
        {
          mechanics.SetHistory(i, j);
        }
      }
      // 否则就是 Bot 走
      else if (mechanics.CheckWin() != Mechanics.Player.First)
      {
        mechanics.AIMove();
      }
    }
  }
}
